# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   1:54 PM Tuesday, 25 September 2012
# * Copyright: AS IS
# *

# condor taskdb api

#' Connect to taskdb
#' @param host Host address of condor taskdb
#' @param username Username of taskdb
#' @param password password of taskdb
#' @param dbname dbname of taskdb
#' @param port port of taskdb
#' @return a connection object of taskdb
#' @export
connectTaskDB <- function(host = '152.83.242.71', user = 'condor', password = 'condor',
    dbname = 'condor', port = 3306)
{
    
    mysql_path <- system.file(package = 'RMySQL')
    if (length(grep('64-bit', sessionInfo()$platform)) > 0)
    {
        mysql_path <- file.path(mysql_path, 'libs', 'x64')
    } else
    {
        mysql_path <- file.path(mysql_path, 'libs', 'i386')
    }
    
    Sys.setenv(MYSQL_HOME = mysql_path)
    library(RMySQL)
    drv <- dbDriver("MySQL")
    con <- dbConnect(drv, user = user, password = password, 
        dbname = dbname, host = host, port = port)
    
    return(con)
}

#' Didconnect to taskDB
#' @param con a connection object as produced by taskDB. 
#' @export
disconnectTaskDB <- function(con)
{
    invisible(dbDisconnect(con))
}


#' create project to taskDB
#' @param con a connection object as produced by taskDB. 
#' @param name name for this project.
#' @param user user for this project.
#' @param table A table name for this project.
#' @param ... Other arguments for project setting
#' @export
newProject <- function(con, name, user = 'nexus\\zhe00a', 
    table = paste('task', name, sep = '_'), ...)
{
    settings <- list(...)
    settings$table <- table
    settings$user <- user
    settings$enc_pass <- ''
    
    settings$name <- name
    setting_db <- as.character(lapply(settings, 
        function(x) 
        {
            x <- paste(x, collapse = ';')
            x <- gsub('\\\\', '\\\\\\\\', x)
            return(x)
        }))
    names(setting_db) <- names(settings)
    tc_col <- dbGetQuery(con, 'SHOW COLUMNS FROM taskconfig')
    pos <- match(tc_col$Field[-1], names(setting_db))
    setting_db <- setting_db[pos]
    sql <- sprintf('INSERT INTO condor.taskconfig (project, %s) VALUES (NULL, %s)',
        paste(sprintf('`%s`', names(setting_db)), collapse = ',\n'),
        paste(sprintf('\'%s\'', setting_db), collapse = ',\n'))
    dbGetQuery(con, sql)
    
    # create a new table
    sql <- sprintf('CREATE TABLE IF NOT EXISTS %s (
  id int(11) NOT NULL AUTO_INCREMENT,
  inputs varchar(2000) NOT NULL,
  commands varchar(2000) NOT NULL,
  outputs varchar(2000) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;', table)
    res <- dbGetQuery(con, sql)
}


#' remove project to taskDB
#' @param con a connection object as produced by taskDB. 
#' @param id project id
#' @param name project name
#' @param user project user
#' @export
removeProject <- function(con, id = NULL, name = NULL, user = NULL)
{
    arg <- list(project = id, name = name, user = user)
    arg <- arg[!unlist(lapply(arg, is.null))]
    if (length(arg) == 0)
    {
        stop('Project id, name or user must be specified')
    }
    if (!is.null(arg$user))
    {
        arg$user <- gsub('\\\\', '\\\\\\\\', arg$user)
    }
    where <- paste(paste(names(arg), ' IN (', unlist(lapply(arg, function(x)
        {
            paste(paste('"', x, '"', sep = ''), collapse = ',')
        })), ')', sep = ''), collapse = ' AND ')
    sql <- sprintf('SELECT tc.table FROM taskconfig AS tc WHERE %s', where)
    
    res <- dbGetQuery(con, sql)
    if (nrow(res) == 0)
    {
        warning('No projects are found')
        return(invisible())
    }
    
    # drop table of project
    apply(res, 1, function(x)
    {
        sql <- sprintf('DROP TABLE IF EXISTS %s', x)
        res <- dbGetQuery(con, sql)
    })

    # Remove setting
    sql <- sprintf('DELETE FROM taskconfig WHERE taskconfig.table IN (%s)', 
        paste(sprintf('\'%s\'', res[[1]]), collapse = ', '))
    res <- dbGetQuery(con, sql)
    invisible(res)
}



#' Clean tasks to taskDB
#' @param con a connection object as produced by taskDB. 
#' @param project project name
#' @export
cleanTasks <- function(con, project)
{
    # Get table name for project
    sql <- sprintf('SELECT taskconfig.table FROM taskconfig 
        WHERE name="%s"', project)
    task_table <- as.character(dbGetQuery(con, sql))
    if (length(task_table) == 0)
    {
        stop(sprintf('Project %s cannot find', project))
    }
    
    sql <- sprintf('DELETE FROM %s WHERE 1', task_table)
    dbGetQuery(con, sql)
}

#' Add tasks to taskDB
#' @param con a connection object as produced by taskDB. 
#' @param project project name
#' @param tasks a data frame write into taskDB
#' @param user user for this project.
#' @export
addTasks <- function(con, project, tasks, clean = FALSE)
{
    # Get table name for project
    sql <- sprintf('SELECT taskconfig.table FROM taskconfig 
        WHERE name="%s"', project)
    task_table <- as.character(dbGetQuery(con, sql))
    
    if (length(task_table) == 0 | task_table == 'character(0)')
    {
        stop(sprintf('Project %s cannot find', project))
    }
    
    if (clean)
    {
        sql <- sprintf('DELETE FROM %s WHERE 1', task_table)
        dbGetQuery(con, sql)
    }
    if (!is.null(tasks$commands))
    {
        # tasks$commands <- gsub('\\\\', '\\\\\\\\', tasks$commands)
        tasks$commands <- gsub('/', '\\\\\\\\', tasks$commands)
    }
    if (!is.null(tasks$outputs))
    {
        # tasks$outputs <- gsub('\\\\', '\\\\\\\\', tasks$outputs)
        tasks$outputs <- gsub('/', '\\\\\\\\', tasks$outputs)
    }
    if (!is.null(tasks$inputs))
    {
        # tasks$inputs <- gsub('\\\\', '\\\\\\\\', tasks$inputs)
        tasks$inputs <- gsub('/', '\\\\\\\\', tasks$inputs)
    }
    
    dbWriteTable(con, task_table, tasks, append = TRUE, row.names = FALSE)
}

#' Reset tasks
#' @param con a connection object as produced by taskDB. 
#' @param project project id
#' @param tasks Task ids. All tasks are reset if NULL
#' @param user user for this project.
#' @export
resetTasks <- function(con, project, tasks = NULL)
{
    # Get table name for project
    # sql <- sprintf('SELECT value FROM taskconfig 
        # WHERE project="%s" AND name="table"', project)
    # task_table <- as.character(dbGetQuery(con, sql))
    # if (length(task_table) == 0)
    # {
        # stop(sprintf('Project %s cannot find', project))
    # }
    # where <- '1'
    # if (!is.null(tasks))
    # {
        # where <- sprintf('id in (%s)',
            # paste(sprintf('"%s"', tasks), collapse = ','))
    # }
    # sql <- sprintf('UPDATE %s SET start = NULL, finish = NULL WHERE %s', 
        # task_table, where)
    # dbGetQuery(con, sql)
}



#' Test projects
#' @param con a connection object as produced by taskDB. 
#' @param project project name
#' @param temp Temporary folder
#' @param id the task id
#' @export
testProject <- function(con, project, temp = 'test', id = 1)
{
    # Get table name for project
    sql <- sprintf('SELECT * FROM taskconfig 
        WHERE name="%s"', project)
    task_table <- dbGetQuery(con, sql)
    if (nrow(task_table) == 0)
    {
        stop(sprintf('Project %s cannot find', project))
    }
    
    # mkdir
    dir.create(temp)
    setwd(temp)
    # copy input files
    inputs <- do.call(c, strsplit(task_table$inputs, ' *; *'))
    check <- file.exists(inputs)
    if (sum(!check) > 0)
    {
        stop(paste0('File doesn\'t exists:\n', paste(inputs[!check], collapse = '')))
    }
    file.copy(inputs, basename(inputs))
    # run initial command
    commands <- do.call(c, strsplit(task_table$init_commands, ' *; *'))
    for (i in seq(along = commands))
    {
        system(commands[i])
    }
    
    # Get a first task
    sql <- sprintf('SELECT `id`, `inputs`, `commands`, `outputs` FROM `%s` WHERE id in %s', 
        task_table$table, paste0('(', paste(id, collapse = ', '), ')'))
    task <- dbGetQuery(con, sql)
    for (i in seq(nrow(task)))
    {
        # copy input files
        inputs <- do.call(c, strsplit(task$inputs[i], ' *; *'))
        check <- file.exists(inputs)
        if (sum(!check) > 0)
        {
            stop(paste0('File doesn\'t exists:\n', paste(inputs[!check], collapse = '')))
        }
        file.copy(inputs, basename(inputs))
        # run commands
        commands <- do.call(c, strsplit(task$commands[i], ' *; *'))
        for (j in seq(along = commands))
        {
            print(commands[j])
            system(commands[j])
        }
        # Copy output files
        outputs <- do.call(c, strsplit(task$outputs[i], ' *; *'))
        check <- file.exists(basename(outputs))
        if (sum(!check) > 0)
        {
            stop(paste0('File doesn\'t exists:\n', paste(basename(outputs[!check]), collapse = '')))
        }
        file.copy(basename(outputs), outputs)
    }
    setwd('..')
}

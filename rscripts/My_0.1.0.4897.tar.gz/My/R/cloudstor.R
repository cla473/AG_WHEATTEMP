# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   06:00 PM Tuesday, 11 October 2016
# * Copyright: AS IS

#' Download files from cloudstor
#'
#' @param url The shared URL of dropbox
#' @param target the target folder of stored file
#' @param cpus Number of cpus for parallel calculation
#' @param overwrite Whether owerwriting the exiting file
#' @export
myDownloadCloudStor <- function(url, target, cpus = 10, overwrite = FALSE) {
    
    library(httr)
    library(xml2)
    library(dplyr)
    recursive_links <- function(url, remote = '/', local = target, links = list()) {
        
        server <- gsub('(.*)/s/(.*)', '\\1', url)
        key <- gsub('.*s/(.*)', '\\1', url)
        list_url <- paste0(server, '/apps/files_sharing/ajax/list.php')
        
        r <- GET(list_url, query = list(t = key, dir = remote, sort = 'name', 
                                        sortdirection = 'asc'), 
                 config = content_type('application/json'))
        con <- content(r)
        if (is.null(con)) {
            stop('empty contents')
        }
        
        # Check remote file path
        if (length(grep('/$', remote)) == 0) {
            remote <- paste0(remote, '/')
        }
        
        # Check remote file path
        if (length(grep('/$', local)) == 0) {
            local <- paste0(local, '/')
        }
        
        # Create the target folder
        dir.create(local, showWarnings = FALSE)
        files <- con$data$files
        for (i in seq(along = files)) {
            # i <- 1
            if (files[[i]]$type == 'dir') {
                remote_new <- paste0(remote, files[[i]]$name)
                local_new <- paste0(local, files[[i]]$name)
                links_i <- recursive_links(url, remote_new, local_new, links)
                links <- c(links, links_i)
            } else if (files[[i]]$type == 'file') {
                remote_link <- paste0(url, '/download?path=', URLencode(remote), '&files=', 
                                      URLencode(files[[i]]$name))
                local_file <- paste0(local, files[[i]]$name)
                links[[length(links) + 1]] <- data_frame(remote = remote_link, local = local_file)
            } else {
                stop('NOT IMPLEMENTED')
            }
        }
        links
    }
    links <- recursive_links(url, local = target, remote = '/')
    links <- bind_rows(links)
    
    if (!overwrite) {
        links <- links[!file.exists(links$local),]
    }
    if (nrow(links) == 0) {
        warning('All files existed or no files need to download')
        return()
    }
    par_download <- function(i, links) {
        download.file(
            as.character(links$remote[i]), 
            destfile = as.character(links$local[i]),
            method = 'libcurl',  mode = 'wb', quiet = TRUE)
    }    
    library(snowfall)
    sfInit(cpus = cpus, parallel = TRUE)
    sfLapply(seq(along = links$remote), par_download, links)
    sfStop()
    
}
# 
# url <- 'https://cloudstor.aarnet.edu.au/plus/index.php/s/oVTPoDk41CmxNoN'
# 
# target <- 'row_detection'
# myDownloadCloudStor(url, target, cpus = 10, overwrite = FALSE)


# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   09:54 PM Wednesday, 10 April 2013
# * Copyright: AS IS
# *


# Weather records

#' Get PPD weather records by station
#' 
#' @param number The number of weather station 
#' @param latitude latitude
#' @param longtitude longitude
#' @param yrange Year range
#' @param file Path of netcdf file
#' @export
myGetPpd <- function(number = NULL, latitude = NULL, longitude = NULL,
                     yrange = NULL,
                     file = '../000-CommonFiles/Results/weather/ncWbPpd.nc')
{
    library(ncdf4)
    nc <- nc_open(file)
    nc_number <- NULL
    pos <- NULL
    if (!is.null(number))
    {
        nc_number <- ncvar_get(nc, 'number')
        pos <- match(number, nc_number)
        nc_number <- nc_number[pos]
    } else if (!is.null(latitude) & !is.null(longitude))
    {
        nc_latitude <- ncvar_get(nc, 'latitude')
        nc_longitude <- ncvar_get(nc, 'longitude')
        library(weaana)
        if (length(latitude) != length(longitude))
        {
            warning('latitude and longitude should have the same length')
            pos <- seq(1, min(length(latitude), length(longitude)))
            latitude <- latitude[pos]
            longitude <- longitude[pos]
        }
        nc_number <- NULL
        for (i in seq(along = latitude))
        {
            dis <- sphericalDistance(latitude[i], longitude[i], nc_latitude, nc_longitude)
            warning(sprintf('The closest PPD station is used with distance %s km',
                            format(min(dis), digits=3)))
            pos[i] <- which.min(dis)
            nc_number[i] <- ncvar_get(nc, 'number', pos[i], 1)
        }
    } else
    {
        stop('No station number specified')
    }
    met <- as.list(NULL)
    for (i in seq(along = nc_number))
    {
        nc_name <- ncvar_get(nc, 'name_lbl', c(1, pos[i]), c(-1, 1))
        nc_latitude <- ncvar_get(nc, 'latitude', pos[i], 1)
        nc_longitude <- ncvar_get(nc, 'longitude', pos[i], 1)
        climates <- ncvar_get(nc, 'climates', c(1, 1, pos[i]), c(-1, -1, 1))
        var <- ncvar_get(nc, 'var_lbl')
    
        climates <- as.data.frame(climates)
        names(climates) <- var
        nc$dim$time
        start_date <- as.Date(gsub('days since ', '', ncatt_get(nc, 'time', 'units')$value))
        end_date <- start_date + nrow(climates) - 1
        date_s <- seq(start_date, end_date, by = 1)
        climates$year <- as.numeric(format(date_s, '%Y'))
        library(weaana)
        climates$day <- DOY(date_s)
        if (!is.null(yrange))
        {
            climates <- climates[climates$year %in% yrange,]
        }
        met[[i]] <- list(Name = as.character(nc_name),
            Number = as.character(nc_number[i]),
            Latitude = as.numeric(nc_latitude),
            Longitude = as.numeric(nc_longitude),
            Records = climates)
    }
    
    nc_close(nc)
    met <- createWeaAna(met)
    met
}


# Weather records

#' Get information of closest PPD weather station
#' 
#' @param latitude latitude
#' @param longtitude longitude
#' @param file Path of netcdf file
#' @export
myFindPpdStation <- function(latitude, longitude,
                     file = project_filepath('Results/weather/ncWbPpd.nc', project = 'com'))
{
    library(ncdf4)
    nc <- nc_open(file)
    nc_number <- NULL
    pos <- NULL
    nc_latitude <- as.numeric(ncvar_get(nc, 'latitude'))
    nc_longitude <- as.numeric(ncvar_get(nc, 'longitude'))
    nc_name <- as.numeric(ncvar_get(nc, 'name_lbl'))
    nc_number <- as.numeric(ncvar_get(nc, 'number'))
    library(weaana)
    distance <- rep(NA, length = length(latitude))
    for (i in seq(along = latitude))
    {
        dis <- sphericalDistance(latitude[i], longitude[i], nc_latitude, nc_longitude)
        distance[i] <- min(dis)
        pos[i] <- which.min(dis)
    }
    nc_close(nc)
    data.frame(latitude = latitude, 
               longitude = longitude,
               ppd_name = nc_name[pos],
               ppd_number = nc_number[pos],
               ppd_latitude = nc_latitude[pos],
               ppd_longitude = nc_longitude[pos],
               distance = distance)
}


#' ENSO type
#'
#' @param years, years
#' @export
myENSO <- function(years)
{
    # Source: http://www.longpaddock.qld.gov.au/products/australiasvariableclimate/index.html
    enso <- read.table(textConnection('2011,La Nina
2013,Neutral
2012,Neutral
2011,La Nina
2010,La Nina
2009,El Nino
2008,La Nina
2007,La Nina
2006,El Nino
2005,Neutral
2004,El Nino
2003,Neutral
2002,El Nino
2001,Neutral
2000,La Nina
1999,La Nina
1998,La Nina
1997,El Nino
1996,La Nina
1995,Neutral
1994,El Nino
1993,El Nino
1992,El Nino
1991,El Nino
1990,Neutral
1989,Neutral
1988,La Nina
1987,El Nino
1986,El Nino
1985,Neutral
1984,Neutral
1983,Neutral
1982,El Nino
1981,Neutral
1980,Neutral
1979,Neutral
1978,Neutral
1977,El Nino
1976,Neutral
1975,La Nina
1974,La Nina
1973,La Nina
1972,El Nino
1971,La Nina
1970,La Nina
1969,El Nino
1968,Neutral
1967,Neutral
1966,Neutral
1965,El Nino
1964,La Nina
1963,El Nino
1962,Neutral
1961,La Nina
1960,Neutral
1959,Neutral
1958,El Nino
1957,El Nino
1956,La Nina
1955,La Nina
1954,La Nina
1953,El Nino
1952,Neutral
1951,El Nino
1950,La Nina
1949,La Nina
1948,Neutral
1947,La Nina
1946,El Nino
1945,Neutral
1944,Neutral
1943,Neutral
1942,La Nina
1941,El Nino
1940,El Nino
1939,El Nino
1938,La Nina
1937,Neutral
1936,Neutral
1935,Neutral
1934,Neutral
1933,Neutral
1932,Neutral
1931,Neutral
1930,Neutral
1929,La Nina
1928,La Nina
1927,Neutral
1926,Neutral
1925,El Nino
1924,La Nina
1923,El Nino
1922,La Nina
1921,La Nina
1920,Neutral
1919,El Nino
1918,El Nino
1917,La Nina
1916,La Nina
1915,Neutral
1914,El Nino
1913,El Nino
1912,Neutral
1911,El Nino
1910,La Nina
1909,La Nina
1908,Neutral
1907,Neutral
1906,La Nina
1905,El Nino
1904,El Nino
1903,La Nina
1902,El Nino
1901,Neutral
1900,El Nino
1899,Neutral
1898,Neutral
1897,La Nina
1896,El Nino
1895,Neutral
1894,Neutral
1893,La Nina
1892,La Nina
1891,Neutral
1890,Neutral'), sep = ',', header = FALSE, as.is = TRUE)
    elnino <- enso$V1[enso$V2 %in% 'El Nino']
    lanina <- c(enso$V1[enso$V2 %in% 'La Nina'])
    # year_type <- c( "neutral", "elnino", "lanina" )    
    year_type <- rep('Neutral', length(years))
    year_type[years %in% elnino] <- 'El Nino'
    year_type[years %in% lanina] <- 'La Nina'
    year_type
}


#' Download SILO weather records
#'
#' @param stations The number of weather station
#' @param output The output folder 
#' @param start The start time of weather records
#' @param end The end time of weather records
#' @export
myDownloadSILO <- function(stations, output, start = '1889/1/1', 
    end = format(Sys.time(), '%Y/%m/%d'))
{
    for (i in seq_along(stations))
    {
        file_name <- file.path(output, sprintf('%s.met', stations[i]))
        base_url <- 'http://apsrunet.apsim.info/cgi-bin/getData.met?format=apsim&station='
        start_date <- as.numeric(strsplit(start, '/')[[1]])
        end_date <- as.numeric(strsplit(end,'/')[[1]])
        
        site_url <- sprintf('%s%s&ddStart=%s&mmStart=%s&yyyyStart=%s&ddFinish=%s&mmFinish=%s&yyyyFinish=%s', 
            base_url, stations[i], 
            start_date[3], start_date[2], start_date[1],
            end_date[3] - 1, end_date[2], end_date[1])
        new_data <- readLines(site_url)
        writeLines(new_data, file_name)
    }
}

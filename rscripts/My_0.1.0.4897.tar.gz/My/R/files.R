# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   09:19 PM Wednesday, 10 April 2013
# * Copyright: AS IS
# *


# file related function

#' Sort files with index
#'
#' @param files A vector of files
#' @export
mySortFiles <- function(files)
{
    num <- as.numeric(gsub('^(\\d+)\\..*$', '\\1', basename(files)))
    files[order(num)]
}


#' Connect to expdb database
#'
#' @param base The base folder of working project
#' @export
myConnectExpDB <- function(base = getwd())
{
    library(expDB)
    con <- connectDB(file.path(base, '../001-expDB/expdb.db'))
    con
}

#' Check genotype
#' @param genotype A vector of genotype
#' @export
myCheckGenotype <- function(genotype, base = getwd())
{
    alias <- read.csv(file.path(base, '../001-expDB/Resources/genotypeAlias.csv'),
        as.is = TRUE)
    alias$Alias <- tolower(alias$Alias)
    alias$Genotype <- tolower(alias$Genotype)
    genotype <- tolower(genotype)
    if (sum(alias$Alias %in% genotype) > 0)
    {
        for (i in seq(length=nrow(alias)))
        {
            genotype[genotype %in% alias$Alias[i]] <- alias$Genotype[i]
        }
    }
    genotype
}

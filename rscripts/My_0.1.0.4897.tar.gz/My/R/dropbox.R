# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   07:54 PM Sunday, 20 March 2016
# * Copyright: AS IS

#' Download file from Dropbox
#' 
#' @param url The shared URL of dropbox
#' @param root the root folder of stored file
#' @param cpus Number of cpus for parallel calculation
#' @param overwrite Whether owerwriting the exiting file
#' @export
myDownloadDropbox <- function(url, target, cpus = 10, overwrite = FALSE) {
    
    library(httr)
    library(xml2)
    library(dplyr)

    text <- content(GET(url))
    
    
    links <- text %>% 
        xml_find_all(".//div[@class='filename-col']/a") %>% 
        xml_attr('href')
    
    files_path <- stringr::str_replace(links, '.*/(.*)\\?dl=0', '\\1')
    
    # files_path <- files_path[seq(1, min(2, length(files_path)))]
    is_files <- stringi::stri_detect_fixed(files_path,  '.')
    folders <- files_path[!is_files]
    links_folder <- links[!is_files]
    
    
    if (length(folders) > 0) {
        for (i in seq(along = folders)) {
            child_folder <- file.path(target, folders[i])
            dir.create(child_folder)
            myDownloadDropbox(links_folder[i], child_folder, cpus, overwrite) 
        }
    }
    files <- files_path[is_files]
    links_files <- links[is_files]
    
    if (length(files) > 0) {
        parDownload <- function(j, links_files, files, root, overwrite) {
            destfile <- file.path(root, files[j])
            if (file.exists(destfile) & !overwrite) {
                return(NULL)
            }
            download.file(
                stringr::str_replace(links_files[j], 'dl=0', 'dl=1'), 
                destfile = destfile,
                method = 'libcurl',  mode = 'wb', quiet = TRUE)
        }
        library(snowfall)
        sfInit(cpus = cpus, parallel = TRUE)
        sfLapply(
            seq(along = files), 
            parDownload, links_files, files, target, overwrite)
        sfStop()
    }
}



# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   09:43 AM Sunday, 24 March 2013
# * Copyright: AS IS
# *

# Project related functions. Only working for my project structure


#' Load a project, the first function will be called when working for a project
#' 
#' @param project The project name
#' @export
myLoadProject <- function(project = NULL, base = getwd())
{
    para <- myReadPara(project = project, base = base)
}

#' Source the function in the project
#'
#' @param force Force to reload all functions
#' @param project The project name
#' @param all Source all functions
#' @export
myProjectFun <- function(force = FALSE, project = NULL, all = FALSE)
{
    is_source <- FALSE
    
    if(!myGetPara('source_fun', project = project) | force)
    {
        is_source <- TRUE
    }
    if (is_source)
    {
        if (!all)
        {
            file <- myFilePath('Rcode', 
                sprintf('%sFunctions.R', myGetPara('prefix', project = project)), 
                project = project)
            source(file)
        } else
        {
            mySourceDir(myFilePath('Rcode', project = project))
        }
        mySetPata('source_fun', TRUE, project = project)
    }
}


#' Construct the path to a file from components in the project
#' 
#' @param ... character vectors
#' @param project The project name
#' @export
myFilePath <- function(..., project = NULL)
{
    base <- myGetPara('base', project = project)
    do.call(file.path, c(list(base), list(...)))
}

#' Read a project file (csv, RData, ...)
#' 
#' @param file a character string giving the name of the file to load
#' @param project The project name
#' @export
myRead <- function(file, project = NULL, var = NULL)
{
    type <- tolower(
        gsub('.*\\.(.*)', '\\1', file))
    file <- myFilePath(file, project = project)
    res <- NULL
    if (type == 'csv')
    {
        if (!is.null(var))
        {
            if (exists(var, .GlobalEnv))
            {
                res <- get(var, .GlobalEnv)
            } else
            {
                res <- read.csv(file, as.is = TRUE)
                assign(var, res, .GlobalEnv)
            }
        } else
        {
            res <- read.csv(file, as.is = TRUE)
        }
        return(res)
    } else if (type == 'rdata')
    {
        load(file, envir = parent.frame())
        # return()
    } else
    {
        stop('NOT IMPLEMENTED')
    }
}

#' Search the file from current folder to root 
#' 
#' @param filename the filename for search
myFindFile <- function(filename, base = getwd())
{
    config <- file.path(base, filename)
    if (!file.exists(config))
    {
        library(stringr)
        base <- gsub('\\\\', '/', base)
        c_file <- unlist(lapply(1:str_count(base, '/'), function(x)
            {
                c_file <- paste(rep('..', x), collapse = '/')
                c_file <- file.path(base, c_file, filename)
                c_file
            }))
        
        pos <- which(file.exists(c_file))
        if (length(pos) == 0)
        {
            stop(paste0(filename, ' does not exist'))
        }
        config <- c_file[pos[1]]
        base <- dirname(config)
    }
    return(config)
}

#' Read ini file
#'
#' @param filename The ini file
myReadIni <- function(filename)
{
    a <- readLines(filename)
    a <- a[-grep('^#', a)]
    a <- a[nchar(a) > 0]
    a <- sub('^\\s+', '', a)
    a <- sub('\\s+$', '', a)
    # for normal parameter
    a1 <- a[grep(' *= *', a)]
    pars1 <- list()
    if (length(a1) > 0)
    {
        a1 <- strsplit(a1, ' *= *')
        pars1 <- lapply(a1, function(x) x[2]) 
        names(pars1) <- as.character(lapply(a1, function(x) x[1]))
        pars1 <- lapply(pars1, function(x)
            {    
                if (length(grep('\\\\\\\\', x)) == 0)
                {
                    x <- gsub('\\\\', '/', x)
                    if (length(grep('/', x)) > 0 & length(grep(':', x)) == 0)
                    {
                        x <- file.path(dirname(filename), x)
                    }
                }
                return (x)
            })
    }
    a2 <- a[grep(' *<- *', a)]
    pars2 <- list()
    if (length(a2) > 0)
    {
        a2 <- strsplit(a2, ' *<- *')
        pars2 <- lapply(a2, function(x) x[2]) 
        names(pars2) <- as.character(lapply(a2, function(x) x[1]))
        pars2 <- lapply(pars2, function(x)
            {    
                x <- eval(parse(text = as.character(x)))
                return (x)
            })
    }
    pars <- c(pars1, pars2)
    pars
}

#' Get the project list
#'
myGetProjectList <- function(base = getwd())
{
    var_name <- 'my_project_list'
    if (exists(var_name))
    {
        p_list <- get(var_name, envir = .GlobalEnv)
    } else
    {
        pro_file <- myFindFile('project.ini', base = base)
        p_list <- myReadIni(pro_file)
        p_list$base <- dirname(pro_file)
        assign(var_name, p_list, envir = .GlobalEnv)
    }
    p_list
}
#' Read parameter files
#'
#' @param project The project name
#' @export
myReadPara <- function(project = NULL, base = NULL)
{
    if (is.null(base))
    {
        if (is.null(project))
        {
            base <- getwd()
        } else
        {
            base <- myGetPara('base')
        }
    } 
    if (is.null(project))
    {
        config <- myFindFile('config.ini', base = base)
    } else
    {
        pro_conf <- myGetProjectList(base)
        if (is.null(pro_conf[[project]]))
        {
            stop(paste0('Project "', project, '" doesn\'t exist'))
        }
        config <- myFindFile('config.ini', 
            file.path(pro_conf$base, pro_conf[[project]]))
    }
    
    # project <- ifelse(is.null(project), paras$config, project)
    var_name <- myVariableName(project)
    if (exists(var_name))
    {
        pars <- get(var_name, envir = .GlobalEnv)
        return (pars)
    }
    
    pars <- myReadIni(config)
    pars$base <- dirname(config)
    pars$source_fun <- FALSE
    assign(var_name, pars, envir = .GlobalEnv)
    return(pars)
}

#' Get parameter from config file
#'
#' @param name The parameter name
#' @param project The project name
#' @export
myGetPara <- function(name = NULL, project = NULL)
{
    var_name <- myVariableName(project)
    if (!exists(var_name))
    {
        myReadPara(project = project)
    }
    pars <- get(var_name, envir = .GlobalEnv)
    if (is.null(name))
    {
        return (pars)
    }
    value <- pars[[name]]
    if (is.null(value))
    {
        stop(sprintf('%s does not exist', name))
    }
    return (value)
}

#' Set parameter
#'
#' @param name The parameter name
#' @param value The parameter value
#' @param project The project name
#' @export
mySetPata <- function(name, value, project = NULL)
{
    var_name <- myVariableName(project)
    pars <- get(var_name, envir = .GlobalEnv)
    pars[[name]] <- value
    assign(var_name, pars, envir = .GlobalEnv)
}

#' Generate variable name for global environment
#' @param project The project name
myVariableName <- function(project = NULL)
{
    if (is.null(project))
    {
        project <- 'current'
    }
    paste0('my_pid_parameters_', project)
}


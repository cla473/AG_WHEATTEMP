# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   06/04/2010
# *


systemCommand <- function(command, res = TRUE)
{
	tryCatch({
		bat_name <- tempfile(tmpdir=".", fileext=".bat")
	
		if (res)
		{
			writeLines(paste(command, ' > temp.txt\n', sep = ''), bat_name)
		} else
		{
			writeLines(command, bat_name)
		}
		system(bat_name, show.output.on.console = FALSE)	
		result <- NULL
		if (res)
		{
			try({
				result <- readLines('temp.txt')
				file.remove('temp.txt')
			}, silent = TRUE)
		}
		file.remove(bat_name)
		return(result)
	}, error = function(e) {
		return(NULL)
	})
}

# Get SVN version and change version number in the DESCRIPTION file
#' Build the R package
#'
#' @param pkg The name of R package
#' @export
myBuildRPackage <- function(pkg, version = '0.1.0')
{
    des_file <- readLines("pkg/DESCRIPTION")
    old_des_file <- des_file
    tryCatch({
        pos <- grep("Version", des_file)
        reversion <- systemCommand('git rev-list HEAD')
        new_version <- paste0(version, '.', length(reversion))
        des_file[pos] <- gsub('(Version: )(.*)', 
            paste0('\\1', new_version),
            des_file[pos])
        writeLines(des_file, "pkg/DESCRIPTION")
        
        # Call roxygen
        system("rm ./pkg/man/*.*")
        library(methods)
        library(utils)
        library(roxygen2)

        roxygenize("pkg")
        system(sprintf("R CMD REMOVE %s", pkg))
        system("R CMD build pkg")
        system(paste("R CMD INSTALL ", pkg, '_', new_version, ".tar.gz" , sep = ""))
        
        system(paste("R CMD check ", pkg, "_", new_version, ".tar.gz" , sep = ""))
        system("R CMD INSTALL --build pkg")
    }, error = function(e) {
        print(e)
    })
    writeLines(old_des_file, "pkg/DESCRIPTION")
}


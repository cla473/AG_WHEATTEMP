# * Author:    Bangyou Zheng (Bangyou.Zheng@csiro.au)
# * Created:   02:10 PM Tuesday, 09 April 2013
# * Copyright: AS IS
# *


# Code related with google 

#' Get geocode by address
#'
#' @param address A address of vector for search
#' @export
myGGeoCode <- function(address) 
{
    library(RCurl)
    library(RJSONIO)
    construct.geocode.url <- function(address, return.call = "json", sensor = "false") 
    {
        root <- "http://maps.google.com/maps/api/geocode/"
        u <- paste(root, return.call, "?address=", address, "&sensor=", sensor, sep = "")
        return(URLencode(u))
    }
    
    lat_lng <- as.data.frame(matrix(rep(NA, length(address) * 3), ncol = 3))
    lat_lng[,1] <- address
    for (i in seq(along = address))
    {
        u <- construct.geocode.url(address[i])
        doc <- getURL(u)
        x <- fromJSON(doc,simplify = FALSE)
        if (x$status != 'OK')
        {
            next
        }
        lat <- x$results[[1]]$geometry$location$lat
        lng <- x$results[[1]]$geometry$location$lng
        lat_lng[i,2:3] <- c(lat, lng)
        Sys.sleep(0.1)
    }
    names(lat_lng) <- c('Address', 'Latitude', 'Longitude')
    return (lat_lng)
}
